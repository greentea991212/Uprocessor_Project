#define DK_OK 0
#define DK_ERR -1